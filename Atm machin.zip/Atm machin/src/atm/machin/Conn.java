package atm.machin;

import java.sql.*;

public class Conn {
//    Create connection

    Connection c;
    Statement s;

    public Conn() {
        try {
            c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root", "Netrapal@1111");
            s = c.createStatement();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
